from django.urls import path

from . import views


# If multiple apps
# How does one make it so that Django knows which app view to create for a url when using the {% url %} template tag?
# add namespaces to your URLconf
app_name= 'polls'

# #------------------------------------------------------
# # BEFORE GENERIC VIEWS
# urlpatterns = [
#     # ex: /polls/
#     path('', views.index, name='index'),
#     # ex: /polls/5/
#     path('<int:question_id>/', views.detail, name='detail'),
#     # ex: /polls/5/results/
#     path('<int:question_id>/results/', views.results, name='results'),
#     # ex: /polls/5/vote/
#     path('<int:question_id>/vote/', views.vote, name='vote'),
# ]

# ------------------------------------------------------
#FOR GENERIC VIEWS 
urlpatterns = [
    path('', views.IndexView.as_view(), name='index'),
    path('<int:pk>/', views.DetailView.as_view(), name='detail'),
    path('<int:pk>/results/', views.ResultsView.as_view(), name='results'),
    path('<int:question_id>/vote/', views.vote, name='vote'),
]
